<?php 
  include 'config.php';
  session_start();
  if (!isset($_SESSION['username'])) {
      header("Location: login.php");
  }
  ?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="style.css" rel="stylesheet" type="text/css" />

</head>

<style>


  .center {
  margin: auto;
  width: 40%;
  padding: 10px;
}

.button {
  background-color: #2F81AD; 
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 25px;
  margin: 4px 2px;
  cursor: pointer;
  -webkit-transition-duration: 0.4s; /* Safari */
  transition-duration: 0.4s;
  border-radius: 8px;
}


.button2:hover {
  box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);
}

</style>


<body>

<div class="header">
  <a href="#default" class="logo">Spitalul Judetean ...</a>
  <div class="header-right">
    <a class="active" href="profilul_meu.php">Profilul meu</a>
    <a href="sectii.php">Sectii</a>
    <a href="personal.php">Personal</a>
    <div class= "dropdown">
    <button class ="dropbtn"><b>Pacienti</b> 
      <i class="fa fa-caret-down"> </i>
    </button>
    <div class= "dropdown-content">
      <a href="lista_pacienti.php"> Lista pacienti </a>
      <a href= "TEST.php"> Adauga pacient </a>
    </div>
  </div>
    <a href="logout.php">Logout</a>
  </div>
</div>

<div style="padding-left:20px">
  
   <?php echo "<h1>Bine ai venit, " . $_SESSION['username'] . "</h1>"; ?>
  <p><img src="profile_picture.png" alt="Trulli" width="250" height="250"></p>
  <p>Descriere</p>
  <p>Descriere</p>
  <p>Descriere</p>
  <p>Descriere</p>
  <p>Descriere</p>
  <p>Descriere</p>
  <p>Descriere</p>

  <h1>Sectii</h1>

<div class="center">
<table>
<tr>
<td>
<button class="button button2">Numele Sectiei</button></td>
<td>
<button class="button button2">Numele Sectiei</button></td>
<td>
<button class="button button2">Numele Sectiei</button>
</td>
</tr>
</tr>
<td>
<button class="button button2">Numele Sectiei</button></td>
<td>
<button class="button button2">Numele Sectiei</button></td>
<td>
<button class="button button2">Numele Sectiei</button>
</td>

</tr>
</table>
</div>

  
</div>


</body>
</html>