<?php 

include 'config.php';

error_reporting(0);

session_start();


if (isset($_POST['submit'])) {
	$nume = $_POST['nume'];
	$prenume = $_POST['prenume'];
	$CNP = $_POST['CNP'];
	$afectiune = $_POST['afectiune'];
	$sectie = $_POST['sectie'];
	$salon = $_POST['salon'];
	$responsabil = $_POST['responsabil'];
	$data_internare = $_POST['data_internare'];
	$data_externare = $_POST['data_externare'];

	
		$sql = "SELECT * FROM adauga_pacient WHERE CNP='$CNP'";
		$result = mysqli_query($conn, $sql);
		if (!$result->num_rows > 0) {
			$sql = "INSERT INTO adauga_pacient (nume, prenume, CNP, afectiune, sectie, salon, responsabil, data_internare, data_externare)
					VALUES ('$nume', '$prenume', '$CNP','$afectiune', '$sectie', '$salon', '$responsabil', '$data_internare', '$data_externare')";
			$result = mysqli_query($conn, $sql);
			if ($result) {
				echo "<script>alert('Wow! the patient was added.')</script>";
				$nume = "";
				$preune = "";
				$CNP = "";
				$afectiune = "";
				$sectie = "";
				$salon = "";
				$responsabil = "";
				$data_internare = "";
				$data_externare = "";
			} else {
				echo "<script>alert('Woops! Something Wrong Went.')</script>";
			}
		} else {
			echo "<script>alert('Woops! CNP is wrong.')</script>";
		}
		
	} 


?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<title>Online Hospital Managment</title>
</head>
	<style>

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
    color:#000;
}

body {
    width: 100%;
    min-height: 100vh;
    background: #ffdccc;
    display: flex;
    justify-content: center;
    align-items: center;
}

.container {
    width: 400px;
    min-height: 400px;
    background: #FFF8F5;
    border-radius: 5px;
    box-shadow: 0 0 5px rgba(0,0,0,.3);
    padding: 40px 30px;
}

.container .login-text {
    color: #111;
    font-weight: 500;
    font-size: 1.1rem;
    text-align: center;
    margin-bottom: 20px;
    display: block;
    text-transform: capitalize;
}


.container .login-email .input-group {
    width: 100%;
    height: 50px;
    margin-bottom: 25px;
}

.container .login-email .input-group input {
    width: 100%;
    height: 100%;
    border: 2px solid #e7e7e7;
    padding: 15px 20px;
    font-size: 1rem;
    border-radius: 30px;
    background: transparent;
    outline: none;
    transition: .3s;
}

.container .login-email .input-group input:focus, .container .login-email .input-group input:valid {
    border-color: #ff8b4d;
}

.container .login-email .input-group .btn {
    display: block;
    width: 100%;
    padding: 15px 20px;
    text-align: center;
    border: none;
    background: #ffac80;
    outline: none;
    border-radius: 30px;
    font-size: 1.2rem;
    color: #FFF;
    cursor: pointer;
    transition: .3s;
}

.container .login-email .input-group .btn:hover {
    transform: translateY(-5px);
    background: #ff8b4d;
}

</style>
<body>
	<div class="container">
		<form action="" method="POST" class="login-email">
            <p class="login-text" style="font-size: 2rem; font-weight: 800;">Adauga pacient</p>
			<div class="input-group">
				<input type="text" placeholder="Nume" name="nume" value="<?php echo $nume; ?>" required>
			</div>
			<div class="input-group">
				<input type="text" placeholder="Prenume" name="prenume" value="<?php echo $prenume; ?>" required>
			</div>
			<div class="input-group">
				<input type="value" placeholder="CNP" name="CNP" value="<?php echo $CNP; ?>" required>
            </div>
            <div class="input-group">
				<input type="text" placeholder="Afectiune" name="afectiune" value="<?php echo $afectiune; ?>" required>
			</div>
			<div class="input-group">
				<input type="text" placeholder="Sectie" name="sectie" value="<?php echo $sectie; ?>" required>
			</div>
			<div class="input-group">
				<input type="Value" placeholder="Salon" name="salon" value="<?php echo $salon; ?>" required>
			</div>
			<div class="input-group">
				<input type="text" placeholder="Doctor" name="responsabil" value="<?php echo $responsabil; ?>" required>
			</div>
			<div class="input-group">
				<input type="date" placeholder="Data internare" name="data_internare" value="<?php echo $data_internare; ?>" required>
			</div>
			<div class="input-group">
				<input type="date" placeholder="Data Externare" name="data_externare" value="<?php echo $data_externare; ?>" required>
			</div>
			<div class="input-group">
				<button name="submit" class="btn">Adauga</button>
			</div>
	<?php 
	session_start();
	if (!isset($_SESSION['username'])) {
  	  header("Location: login.php");
	}
	?>
    <a href="profilul_meu.php">Inapoi</a>
		</form>
	</div>
</body>
</html>