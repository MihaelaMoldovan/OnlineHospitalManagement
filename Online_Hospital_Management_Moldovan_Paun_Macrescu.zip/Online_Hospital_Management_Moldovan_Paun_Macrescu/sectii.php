<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <title>replit</title>
    <link href="style.css" rel="stylesheet" type="text/css" />
  </head>
  <style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}
h2 {
  margin: auto;
  width: 10%;
  padding: 10px;
}
td, th {
  border: 1px solid #dddddd;
  text-align: center;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
  <body>

  <div class="header">
  <a href="#default" class="logo">Spitalul Judetean ...</a>
  <div class="header-right">
    <a href="profilul_meu.php">Profilul meu</a>
    <a class="active"  href="sectii.php">Sectii</a>
    <a href="personal.php">Personal</a>
    <div class= "dropdown">
    <button class ="dropbtn">Pacienti 
      <i class="fa fa-caret-down"> </i>
    </button>
    <div class= "dropdown-content">
      <a href="lista_pacienti.php"> Lista pacienti </a>
      <a href= "TEST.php"> Adauga pacient </a>
    </div>
  </div>
    <a href="logout">Logout</a>
  </div>
</div>
<h1> Sectia de interne </h1>



<h2>Lista personal </h2>

   <?php
$dbc = mysqli_connect("localhost","root","", "ohm");
$res=mysqli_query($dbc, "select * from doctor where sectie= 'interne'");

$abc=mysqli_query($dbc, "SELECT count(*) as c FROM adauga_pacient");


echo "<table>";
echo"<th>"?>Nume<?php
echo"<th>"?>Prenume<?php
echo"<th>"?>CNP<?php
echo"<th>"?>Sectie<?php

while($row=mysqli_fetch_array($res))
{
  echo "<tr>";  
  echo "<td>"; echo $row["nume"];echo"</td>";
  echo"<td>"; echo $row["prenume"]; echo"</td>";
  echo "<td>"; echo $row["CNP"];echo"</td>";
  echo "<td>"; echo $row["sectie"];echo"</td>";
  
  echo "</tr>";
}




echo "</table>";
 ?> 
 <br>
 <br>
 <br>
 <h2> Lista pacienti   </h2>
 <?php
$dbc = mysqli_connect("localhost","root","", "ohm");
$res=mysqli_query($dbc, "select * from adauga_pacient where sectie= 'interne'");



echo "<table>";
echo"<th>"?>Nume<?php
echo"<th>"?>Prenume<?php
echo"<th>"?>CNP<?php
echo"<th>"?>Afectiune<?php
echo"<th>"?>Sectie<?php
echo"<th>"?>Salon<?php
echo"<th>"?>Doctor<?php

while($row=mysqli_fetch_array($res))
{
  echo "<tr>";  
  echo "<td>"; echo $row["nume"];echo"</td>";
  echo"<td>"; echo $row["prenume"]; echo"</td>";
  echo "<td>"; echo $row["CNP"];echo"</td>";
  echo "<td>"; echo $row["afectiune"];echo"</td>";
  echo "<td>"; echo $row["sectie"];echo"</td>";
  echo "<td>"; echo $row["salon"];echo"</td>";
  echo "<td>"; echo $row["responsabil"];echo"</td>";
  
  echo "</tr>";
}
echo "</table>";
 ?>   

    
  </body>
</html>